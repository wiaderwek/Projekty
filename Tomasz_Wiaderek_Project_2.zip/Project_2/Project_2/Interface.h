#ifndef INTERFACE_H_
#define INTERFACE_H_
#include <iostream>
#include <string>
#include "Enigma.h"
using namespace std;


class Interface
{
    private:
        Enigma en;
    public:
        void program();
        int from_keyboard_or_file();
        void set_settings(char * settings, int n);
        string get_settings(int cho);
        string get_message(int cho);
        string code_message(string message);
        void save_message(char * settings, int n, string message, string coded_message);
        void save_or_not(char * settings, int n, string message, string coded_message);


};
#endif
