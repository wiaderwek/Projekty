#include <iostream>
#include <cstdlib>
#include <string>
#include "Rotor.h"
#include "Enigma.h"
#include "Interface.h"
using namespace std;


int main()
{
    Interface *in = new Interface;
    in->program();
    delete in;

    cin.get(),cin.get();
    return 0;
}
