#ifndef ROTORELEMENT_H_
#define ROTORELEMENT_H_
using namespace std;

class RotorElement
{
    public:
        RotorElement * next;
        RotorElement * prev;
        char cha1;
        char cha2;
};

#endif
