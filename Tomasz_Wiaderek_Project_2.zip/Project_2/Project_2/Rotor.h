#ifndef ROTOR_H_
#define ROTOR_H_
#include <iostream>
#include <array>
#include "RotorElement.h"
using namespace std;

template <typename T>
class Rotor
{

    RotorElement r_el;
    typedef RotorElement* Rotor_ptr;
    Rotor_ptr  ptr;
    int size_of_rotor;

    public:
    Rotor( T *shifts, int n);
    void show();
    void set_rotor_ptr_at_first_element();
    void turn_rotor_once();
    char get_char1(T c);
    char get_char2(T c);
    void set_rotor(T c);

};
 ////////////////////////////////////////////////////////////////

template <typename T>
Rotor<T>::Rotor( T * rotor_shift, int n)
{
    RotorElement *first=new RotorElement;
    size_of_rotor=n;
    first->cha2=rotor_shift[0];
    first->cha1='A';
    first->next=ptr;
    ptr=first;
    for (int i=1; i<size_of_rotor-1; i++)
    {
        RotorElement * ad = new RotorElement;
        ptr->next=ad;
        ad->prev=ptr;
        ptr=ad;
        ad->cha2=rotor_shift[i];
        ad->cha1=(char)(65+i);    //65 is A in ASCII code
        ptr=ad;
    }
    RotorElement * last = new RotorElement;
    ptr->next=last;
    first->prev=last;
    last->next=first;
    last->prev=ptr;
    last->cha2=rotor_shift[size_of_rotor-1];
    last->cha1='Z';
    ptr=first;

}

template <typename T>
void Rotor<T>::set_rotor_ptr_at_first_element()
{
    for(int i=0; i<size_of_rotor; i++)
    {
        if(ptr->cha1=='A') break;
        else ptr=ptr->next;
    }
}

template <typename T>
void Rotor<T>::show()
{
    set_rotor_ptr_at_first_element();
    for (int i=0; i<size_of_rotor; i++)
    {
        cout<< ptr->cha2 << " ";
        ptr=ptr->next;
    }
    cout << endl;

}

template <typename T>
void Rotor<T>::turn_rotor_once()
{
    set_rotor_ptr_at_first_element();
    RotorElement *tmp=new RotorElement;
    (tmp->cha2)=(ptr->cha2);
    for(int i=0; i<size_of_rotor-1; i++)
    {
        (ptr->cha2)=((ptr->next)->cha2);
        ptr=(ptr->next);
    }
    (ptr->cha2)=(tmp->cha2);
    delete tmp;
}


template <typename T>
char Rotor<T>::get_char2(T c)
{
    set_rotor_ptr_at_first_element();
    for(int i=0; i<size_of_rotor; i++)
    {
        if((ptr->cha1)==c) return (ptr->cha2);
        ptr=(ptr->next);
    }
}

template <typename T>
char Rotor<T>::get_char1(T c)
{
    set_rotor_ptr_at_first_element();
    for(int i=0; i<size_of_rotor; i++)
    {
        if((ptr->cha2)==c) return (ptr->cha1);
        ptr=(ptr->next);
    }
}

template <typename T>
void Rotor<T>::set_rotor(T c)
{
    set_rotor_ptr_at_first_element();
    while((ptr->cha2)!=c)
    {
        turn_rotor_once();
        set_rotor_ptr_at_first_element();
    }
}


#endif // ROTOR_H_
