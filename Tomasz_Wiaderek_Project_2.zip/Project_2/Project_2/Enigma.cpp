#include <iostream>
#include <array>
#include "Rotor.h"
#include "Enigma.h"
using namespace std;

Enigma::Enigma()
{
    rotors[0]= new Rotor<char>(rot1, 26);
    rotors[1]= new Rotor<char>(rot2, 26);
    rotors[2]= new Rotor<char>(rot3, 26);
    rotors[3]= new Rotor<char>(rot_mirror, 26);
}

Enigma::~Enigma()
{
    delete rotors[0];
    delete rotors[1];
    delete rotors[2];
    delete rotors[3];
}

string Enigma::code(string message)
{
    string coded="";
    for(int i=0; i<message.size(); i++)
    {
        if((int)message[i]>=65 && (int)message[i]<=90)  // from A to Z in ASCII
        {
            coded+=rotors[0]->get_char1(rotors[1]->get_char1(rotors[2]->get_char1(rotors[3]->get_char2(rotors[2]->get_char2(rotors[1]->get_char2(rotors[0]->get_char2(message[i])))))));
            rotors[0]->turn_rotor_once();
        }
        else
        {
            coded+=message[i];
        }
    }
    return coded;
}

void Enigma::rotors_settings(char * settings, int n)
{
    rotors[0]->set_rotor(settings[0]);
    rotors[1]->set_rotor(settings[1]);
    rotors[2]->set_rotor(settings[2]);

}


