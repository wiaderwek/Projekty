#include <iostream>
#include <windows.h>
#include <fstream>
#include <conio.h>
#include <string>
#include "Interface.h"
#include "Enigma.h"

using namespace std;

void Interface::program()
{
    int n=from_keyboard_or_file();
    if(n==1 || n==2)
    {

        string s=get_settings(n);
        char settings[3];
        for(int i=0; i<3; i++)
        {
            settings[i]=s[i];
        }
        set_settings(settings, 3);
        string message=get_message(n);
        string coded_message=code_message(message);
        cout << coded_message;
        save_or_not(settings, 3, message, coded_message );
        program();
    }
}

int Interface::from_keyboard_or_file()
{
    int choice;
    cout << "1.Get data from keybord" << endl << "2.Get data from file" << endl <<"3.End Program" << endl <<  "Your choice: ";
    cin >> choice;
    Sleep(300);
    system("cls");
    return choice;
}


void Interface::set_settings(char *settings, int n)
{
    en.rotors_settings(settings, n);
}

string Interface::get_settings(int cho)
{
    string settings;

    if(cho==1)
    {
        cout << "Rotors settings: ";
        for(int i=0; i<3; i++)
        {
            settings[i]=getch();
            if (((int)settings[i])>=97 && ((int)settings[i])<123)
            {
                settings[i]=(char)(((int)settings[i])-32);
            }
            cout <<settings[i];
        }
        cout << endl;
        return settings;
    }
    else
    {
        ifstream file;
        file.open("kod.txt");
        string message;
        if( file.good() == true)
        {
            getline(file, message);
            cout << "Rotors settings: ";
            for(int i=0; i<3; i++)
            {
                settings[i]=message[i];
                if (((int)settings[i])>=97 && ((int)settings[i])<123)
                {
                    settings[i]=(char)(settings[i]-32);
                }
                cout <<settings[i];
            }
            cout << endl;
            file.close();
            return settings;
        }
        else
        {
            cout << "Error: problem with file!!" << endl;
            return NULL;
        }
    }
}

string Interface::get_message(int cho)
{
    string message="";
    if(cho==1)
    {
        cout << "Message: ";
        char ch;
        ch=getch();
        while((int)ch!=13) // 13 is ascii enter
        {
            if (((int)ch)>=97 && ((int)ch)<123)
            {
                ch=(char)(ch-32);
            }
            cout << ch;
            message+=ch;
            ch=getch();
        }
        cout << endl;
        return message;
    }
    else
    {
        string mes;
        ifstream file;
        file.open("kod.txt");
        getline(file, mes);
        cout << endl << "Message: " << endl;
        int n=0;
        while(!file.eof())
        {
            getline(file, mes);
            for(int i=0; i<mes.size(); i++)
            {
                message+=mes[i];
                if (((int)message[i+n])>=97 && ((int)message[i+n])<123)
                {
                    message[i+n]=(char)(message[i+n]-32);
                }
                cout <<message[i+n];
            }
            message+='\n';
            n+=mes.size()+1;
            cout << endl;
        }
        file.close();
        cout << endl;
        return message;
    }
}

string Interface::code_message(string message)
{
    string coded_message="";
    coded_message+=en.code(message);

    return coded_message;
}

void Interface::save_message(char* settings, int n, string message, string coded_message)
{
    ofstream file;
    file.open("C:\\Users\\Tomasz\\Desktop\\Project_2\\Project_2\\kod.txt");
    file<<settings[1];
    file<<settings[1];
    file<<settings[2];
    file <<"\n";
    file<<message;
    file<<"\n";
    file<<coded_message;

    file.close();
    Sleep(300);
    system("cls");
}

void Interface::save_or_not(char * settings, int n, string message, string coded_message)
{
    cout << endl << "Do you want save your enigma's message? [y/n]" << endl << "Your choice: ";
    char c;
    cin >> c;
    if(c=='y')
    {
        save_message(settings , n, message, coded_message);
    }
    else if(c!='n')
    {
        save_or_not(settings, n, message, coded_message);
    }
    Sleep(300);
    system("cls");
}
