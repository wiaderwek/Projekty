#ifndef ENIGMA_H_
#define ENIGMA_H_
#include <iostream>
#include "Rotor.h"
#include <string>
using namespace std;


class Enigma
{
    Rotor<char> *rotors[3];
    char rot1[26]= {'D','M','T','W','S','I','L','R','U','Y','Q','N','K','F','E','J','C','A','Z','B','P','G','X','O','H','V'};
    char rot2[26]= {'H','Q','Z','G','P','J','T','M','O','B','L','N','C','I','F','D','Y','A','W','V','E','U','S','R','K','X'};
    char rot3[26]= {'U','Q','N','T','L','S','Z','F','M','R','E','H','D','P','X','K','I','B','V','Y','G','J','C','W','O','A'};
    char rot_mirror[26]= {'Y','R','U','H','Q','S','L','D','P','X','N','G','O','K','M','I','E','B','F','Z','C','W','V','J','A','T'};
public:
    Enigma();
    ~Enigma();
    string code(string message);
    void rotors_settings(char *settings, int n);
};
#endif
