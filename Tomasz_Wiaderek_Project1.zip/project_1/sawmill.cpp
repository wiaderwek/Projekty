#include<iostream>
#include<ctime>
#include<cstdlib>
#include "sawmill.h"

using namespace std;

Sawmill::Sawmill(int w, int b, int ti, int e, int c1, int c2, int c3)
{
    wood = w;
    broken = b;
    t = ti;
    n_of_engineers = e;
    cost[0]=c1;
    cost[1]=c2;
    cost[2]=c3;
}

void Sawmill::show()
{
    cout << "You need " << time << " round/s, " << n_of_engineers << " engineers, " << cost[0] << " wood, " << cost[1] << " stone, " << cost[2] << " gold to get " << wood << " wood" << endl;
}

void Sawmill::crush()
{
    broken=1;
}


void Sawmill::repair()
{
    broken=0;
}

int Sawmill::get_wood(int n)
{
    srand( time( NULL ) );
    int m;
        if (broken == 0)
        {
            if ((m=rand()%10)==7)
            {
                crush();
                cout << "One of your sawmills in out of order!" << endl;
                return 0;
            }
            else if(n%t==0) return wood;
        }
        else if ((m=rand()%10)!=7)
        {
            repair();
            cout << "Your sawmill has been fixed!" << endl;
            return 0;
        }

}

int Sawmill::get_n_of_engineers()
{
    return n_of_engineers;
}

int Sawmill::get_cost_w()
{
    return cost[0];
}

int Sawmill::get_cost_s()
{
    return cost[1];
}

int Sawmill::get_cost_g()
{
    return cost[2];
}
