#ifndef Goldmine_H_
#define Goldmine_H_

using namespace std;

class Goldmine
{
    private:
        int gold;
        bool broken;
        int t;
        int n_of_engineers;
        int cost[3];

    public:
        Goldmine(int g=5, int b=0, int ti=1, int e=3, int c1=100, int c2=50, int c3=50);
        void show();
        void repair();
        void crush();
        int get_gold(int n);
        int get_n_of_engineers();
        int get_cost_w();
        int get_cost_s();
        int get_cost_g();
};
#endif
