
#ifndef Sawmill_H_
#define Sawmill_H_


using namespace std;

class Sawmill
{
    private:
        int wood;
        bool broken;
        int t;
        int n_of_engineers;
        int cost[3];

    public:
        Sawmill(int w=10, int b=0, int ti=1, int e=2, int c1=70, int c2=0, int c3=0);
        void show();
        void repair();
        void crush();
        int get_wood(int n);
        int get_n_of_engineers();
        int get_cost_w();
        int get_cost_s();
        int get_cost_g();

};
#endif
