#include<iostream>
#include<ctime>
#include<cstdlib>
#include "engineer.h"

using namespace std;

Engineer::Engineer(int c)
{
    cost=c;
}
Engineer::get_cost()
{
    return cost;
}

