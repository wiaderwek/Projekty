#include<iostream>
#include<ctime>
#include<cstdlib>
#include <vector>
#include "castle.h"
#include "sawmill.h"
#include "quarry.h"
#include "goldmine.h"

using namespace std;

Castle::Castle(long w, long s, long g, long e)
{
    q_of_wood = w;
    q_of_stone = s;
    q_of_gold = g;
    for (int i=0; i<e; i++)
    {
        Engineer a;
        engineers.push_back(a);
    }
}

Castle::show()
{
    cout << "You have " << q_of_wood << " wood, " << q_of_stone << " stone, " << q_of_gold << " gold and " << engineers.size() << " enginers." << endl;
    cout << sawmills.size() << " sawmills, " << quarries.size() << " quarries and " << goldmines.size() << " goldmines belong to your kingdom." << endl;
}

Castle::add_engineer()
{
    Engineer *e=new Engineer;
    if (q_of_gold<e->get_cost())
    {
        cout << "You have not enough gold!!!" << endl;
        delete e;
    }
    else
    {
        engineers.push_back(*e);
        q_of_gold-=e->get_cost();
        cout << "New engineer was added to your kingdom! Now you have " << engineers.size() << " engineers." << endl;
    }

}

Castle::add_sawmill()
{
    Sawmill *a = new Sawmill();
    if(q_of_wood<a->get_cost_w() || q_of_stone<a->get_cost_s() || q_of_gold<a->get_cost_g() || engineers.size()<a->get_n_of_engineers())
    {
        cout << "You have not enough resources!!!" << endl;
        delete a;
    }
    else
    {
        sawmills.push_back(*a);
        q_of_wood-=a->get_cost_w();
        q_of_stone-=a->get_cost_s();
        q_of_gold-=a->get_cost_g();
        for (int i=0; i<a->get_n_of_engineers(); i++)
        {
            engineers.pop_back();
        }
        cout << "You have now " << sawmills.size() << " sawmills." << endl;
    }
}

Castle::add_quarry()
{
    Quarry *a = new Quarry;
    if(q_of_wood<a->get_cost_w() || q_of_stone<a->get_cost_s() || q_of_gold<a->get_cost_g() || engineers.size()<a->get_n_of_engineers())
    {
        cout << "You have not enough resources!!!" << endl;
        delete a;
    }
    else
    {
        quarries.push_back(*a);
        q_of_wood-=a->get_cost_w();
        q_of_stone-=a->get_cost_s();
        q_of_gold-=a->get_cost_g();
        for (int i=0; i<a->get_n_of_engineers(); i++)
        {
            engineers.pop_back();
        }
        cout << "You have now " << quarries.size() << " quarries." << endl;
    }
}

Castle::add_golmine()
{
    Goldmine *a = new Goldmine;
    if(q_of_wood<a->get_cost_w() || q_of_stone<a->get_cost_s() || q_of_gold<a->get_cost_g() || engineers.size()<a->get_n_of_engineers())
    {
        cout << "You have not enough resources!!!" << endl;
        delete a;
    }
    else
    {
        goldmines.push_back(*a);
        q_of_wood-=a->get_cost_w();
        q_of_stone-=a->get_cost_s();
        q_of_gold-=a->get_cost_g();
        for (int i=0; i<a->get_n_of_engineers(); i++)
        {
            engineers.pop_back();
        }
        cout << "You have now " << goldmines.size() << " goldmines." << endl;
    }
}

Castle::collect_resources(int n)
{
    srand( time( NULL ) );
    int m;
    for(int i=0; i<sawmills.size(); i++)
    {
      q_of_wood+=sawmills[i].get_wood(n);
    }

    for(int i=0; i<quarries.size(); i++)
    {
        q_of_stone+=quarries[i].get_stone(n);
    }

    for(int i=0; i<goldmines.size(); i++)
    {
        q_of_gold+=goldmines[i].get_gold(n);
    }
}
