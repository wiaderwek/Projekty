#include<iostream>
#include<ctime>
#include<cstdlib>
#include "quarry.h"

using namespace std;

Quarry::Quarry(int s, int b, int ti, int e, int c1, int c2, int c3)
{
    stone = s;
    broken = b;
    t = ti;
    n_of_engineers = e;
    cost[0]=c1;
    cost[1]=c2;
    cost[2]=c3;
}

void Quarry::show()
{
    cout << "You need " << time << " round/s, " << n_of_engineers << " engineers, " << cost[0] << " wood, " << cost[1] << " stone, " << cost[2] << " gold to get " << stone << " stone" << endl;
}

void Quarry::crush()
{
    broken=1;
}


void Quarry::repair()
{
    broken=0;
}

int Quarry::get_stone(int n)
{
    srand( time( NULL ) );
    int m;
        if (broken == 0)
        {
            if ((m=rand()%10)==7)
            {
                crush();
                cout << "One of your quarries in out of order!" << endl;
                return 0;
            }
            else if(n%t==0) return stone;
        }
        else if ((m=rand()%10)!=7)
        {
            repair();
            cout << "Your quarry has been fixed!" << endl;
            return 0;
        }

}

int Quarry::get_n_of_engineers()
{
    return n_of_engineers;
}

int Quarry::get_cost_w()
{
    return cost[0];
}

int Quarry::get_cost_s()
{
    return cost[1];
}

int Quarry::get_cost_g()
{
    return cost[2];
}
