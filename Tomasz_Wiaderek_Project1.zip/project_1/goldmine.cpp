#include<iostream>
#include<ctime>
#include<cstdlib>
#include "goldmine.h"

using namespace std;

Goldmine::Goldmine(int g, int b, int ti, int e, int c1, int c2, int c3)
{
    gold= g;
    broken = b;
    t = ti;
    n_of_engineers = e;
    cost[0]=c1;
    cost[1]=c2;
    cost[2]=c3;
}

void Goldmine::show()
{
    cout << "You need " << time << " round/s, " << n_of_engineers << " engineers, " << cost[0] << " wood, " << cost[1] << " stone, " << cost[2] << " gold to get " << gold << " gold" << endl;
}

void Goldmine::crush()
{
    broken=1;
}


void Goldmine::repair()
{
    broken=0;
}

int Goldmine::get_gold(int n)
{
    srand( time( NULL ) );
    int m;
        if (broken == 0)
        {
            if ((m=rand()%10)==7)
            {
                crush();
                cout << "One of your goldmines in out of order!" << endl;
                return 0;
            }
            else if(n%t==0) return gold;
        }
        else if ((m=rand()%10)!=7)
        {
            repair();
            cout << "Your goldmine has been fixed!" << endl;
            return 0;
        }

}

int Goldmine::get_n_of_engineers()
{
    return n_of_engineers;
}

int Goldmine::get_cost_w()
{
    return cost[0];
}

int Goldmine::get_cost_s()
{
    return cost[1];
}

int Goldmine::get_cost_g()
{
    return cost[2];
}
