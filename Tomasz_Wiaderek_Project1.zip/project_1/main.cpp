#include<iostream>
#include<ctime>
#include<windows.h>
#include<cstdlib>
#include <vector>
#include "castle.h"
#include "sawmill.h"
#include "quarry.h"
#include "goldmine.h"
#include "engineer.h"
const int WAIT=300;

using namespace std;

int automatic_test(Castle castle, int n)
{
    castle.show();
    castle.add_engineer();
    castle.add_sawmill();
    castle.add_golmine();
    castle.collect_resources(n);
    cout << endl << "Next tour!" << endl;
    n++;
    castle.show();
    castle.collect_resources(n);
    cout << endl << "Next tour!" << endl;
    castle.show();
    castle.add_quarry();
    castle.add_engineer();
    castle.add_engineer();
    castle.collect_resources(n);
    n++;
    cout << endl << "Next tour!" << endl;
    castle.show();
    castle.collect_resources(n);
    n++;
    cout << endl << "Next tour!" << endl;
    castle.show();
    castle.collect_resources(n);
    n++;
    cout << endl << "Next tour!" << endl;
    castle.show();
    castle.add_quarry();
    castle.collect_resources(n);
    n++;
    while(n<20)
    {
        castle.show();
        castle.add_engineer();
        castle.add_sawmill();
        castle.add_golmine();
        castle.collect_resources(n);
        cout << endl << "Next tour!" << endl;
        n++;
        castle.show();
        castle.collect_resources(n);
        cout << endl << "Next tour!" << endl;
        castle.show();
        castle.add_quarry();
        castle.add_engineer();
        castle.add_engineer();
        castle.collect_resources(n);
        n++;
        cout << endl << "Next tour!" << endl;
        castle.show();
        castle.collect_resources(n);
        n++;
        cout << endl << "Next tour!" << endl;
        castle.show();
        castle.collect_resources(n);
        n++;
        cout << endl << "Next tour!" << endl;
        castle.show();
        castle.add_quarry();
        castle.collect_resources(n);
        n++;
    }


}

int manual_game(Castle castle, int n)
{
    castle.show();
    cout << "1. Buy engineer [50g]" << endl << "2. Build sawmill [2e,70w]" << endl << "3. Build quarry [3e,100w, 50s, 20g]"
    << endl << "4. Build goldmine [3e, 100w, 50s, 50g]" << endl << "5. Next tour" << endl
    << "6. End game" << endl << endl << "Your choice: ";
    int ch;
    cin >> ch;
    if (ch==1)
    {
        castle.add_engineer();
        Sleep(WAIT);
        system("cls");
        manual_game(castle, n);
    }
    else if(ch==2)
    {
        castle.add_sawmill();
        Sleep(WAIT);
        system("cls");
        manual_game(castle, n);
    }
    else if(ch==3)
    {
        castle.add_quarry();
        Sleep(WAIT);
        system("cls");
        manual_game(castle, n);
    }
    else if(ch==4)
    {
        castle.add_golmine();
        Sleep(WAIT);
        system("cls");
        manual_game(castle, n);
    }
    else if (ch==5)
    {
        castle.collect_resources(n);
        n++;
        Sleep(WAIT);
        system("cls");
        manual_game(castle, n);
    }
    else if(ch==6)
    {
        return 0;
    }
    else manual_game(castle, n);
}

int menu()
{
    Castle castle;
    int n=1;
    int c;
    cout << "1. Manual game" << endl << "2. Automatic test" << endl << "3. End of program" << endl << endl << "Your choice: ";
    cin >> c;
    if(c==1)
    {
        Sleep(WAIT);
        system("cls");
        manual_game(castle, n);
    }
    else if(c==2)
    {
        automatic_test(castle, n);
    }
    else if (c==3)
    {
       return 0;
    }
    else
    {
        menu();
    }
}

int main()
{
    menu();
    return 0;
}
