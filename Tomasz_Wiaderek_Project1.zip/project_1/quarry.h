#ifndef Quarry_H_
#define Quarry_H_

using namespace std;

class Quarry
{
    private:
        int stone;
        bool broken;
        int t;
        int n_of_engineers;
        int cost[3];

    public:
        Quarry(int s=5, int b=0, int ti=1, int e=3, int c1=100, int c2=50, int c3=20);
        void show();
        void repair();
        void crush();
        int get_stone(int n);
        int get_n_of_engineers();
        int get_cost_w();
        int get_cost_s();
        int get_cost_g();
};
#endif
