#ifndef Castle_H_
#define Castle_H_
#include <vector>
#include <iostream>
#include "sawmill.h"
#include "quarry.h"
#include "goldmine.h"
#include "engineer.h"

using namespace std;

class Castle
{
private:
    long q_of_wood;
    long q_of_stone;
    long q_of_gold;
    vector<Engineer> engineers;
    vector<Sawmill> sawmills;
    vector<Quarry> quarries;
    vector<Goldmine> goldmines;


public:
    Castle(long w=500, long s=300, long g=200, long e=5);
    int show();
    int add_sawmill();
    int add_quarry();
    int add_golmine();
    int add_engineer();
    int collect_resources(int n);
    friend ostream& operator<<(ostream& os, Castle &c)
    {
        os<< "You have " << c.q_of_wood << " wood, " << c.q_of_stone << " stone, " << c.q_of_gold << " gold and " << c.engineers.size() << " enginers." << endl
          << c.sawmills.size() << " sawmills, " << c.quarries.size() << " quarries and " << c.goldmines.size() << " goldmines belong to your kingdom." << endl;
        return os;
    };
};
#endif
