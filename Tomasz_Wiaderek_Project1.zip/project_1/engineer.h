#ifndef Engineer_H_
#define Engineer_H_


using namespace std;

class Engineer
{
    private:
        int cost;

    public:
        Engineer(int c=50);
        int get_cost();

};
#endif
